import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { CreateStudentDto } from './dto/create-student.dto.js';
import { UpdateStudentDto } from './dto/update-student.dto.js';
import { StudentsService } from './students.service.js';

@Controller('students')
export class StudentsController {
  constructor(private readonly studentsService: StudentsService) {}

  @Post()
  async create(@Body() dto: CreateStudentDto) {
    const data = await this.studentsService.create(dto);
    return {
      statusCode: 201,
      message: 'Berhasil menambahkan data mahasiswa',
      data,
    };
  }

  @Get()
  async findAll(@Query('major') major?: string) {
    const data = await this.studentsService.findAll(major);
    return {
      statusCode: 200,
      message: 'Berhasil mengambil data mahasiswa',
      data,
    };
  }

  @Get('stats')
  async getStats() {
    const data = await this.studentsService.getStats();
    return {
      statusCode: 200,
      message: 'Berhasil mengambil statistik mahasiswa',
      data,
    };
  }

  @Get(':id')
  async findOne(@Param('id', ParseIntPipe) id: number) {
    const data = await this.studentsService.findOne(id);
    return {
      statusCode: 200,
      message: 'Berhasil mengambil detail mahasiswa',
      data,
    };
  }

  @Patch(':id')
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateStudentDto,
  ) {
    const data = await this.studentsService.update(id, dto);
    return {
      statusCode: 200,
      message: 'Berhasil memperbarui data mahasiswa',
      data,
    };
  }

  @Delete(':id')
  async remove(@Param('id', ParseIntPipe) id: number) {
    const data = await this.studentsService.remove(id);
    return {
      statusCode: 200,
      message: 'Berhasil menghapus data mahasiswa',
      data,
    };
  }
}
