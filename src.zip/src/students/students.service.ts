import { Injectable, NotFoundException } from '@nestjs/common';
import type { Student } from '../../prisma/generated/client.js';
import { PrismaService } from '../../prisma/prisma.service.js';
import { CreateStudentDto } from './dto/create-student.dto.js';
import { UpdateStudentDto } from './dto/update-student.dto.js';

@Injectable()
export class StudentsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateStudentDto): Promise<Student> {
    return this.prisma.student.create({
      data: dto,
    });
  }

  async findAll(major?: string): Promise<Student[]> {
    return this.prisma.student.findMany({
      where: major
        ? {
            major: {
              contains: major,
              mode: 'insensitive',
            },
          }
        : undefined,
      orderBy: { id: 'asc' },
    });
  }

  async findOne(id: number): Promise<Student> {
    const student = await this.prisma.student.findUnique({
      where: { id },
    });
    if (!student) {
      throw new NotFoundException(`Mahasiswa dengan id ${id} tidak ditemukan`);
    }
    return student;
  }

  async update(id: number, dto: UpdateStudentDto): Promise<Student> {
    await this.findOne(id);
    return this.prisma.student.update({
      where: { id },
      data: dto,
    });
  }

  async remove(id: number): Promise<Student> {
    await this.findOne(id);
    return this.prisma.student.delete({
      where: { id },
    });
  }

  async getStats() {
    const totalStudents = await this.prisma.student.count();
    const byMajor = await this.prisma.student.groupBy({
      by: ['major'],
      _count: { id: true },
    });

    return {
      totalStudents,
      byMajor: byMajor.map((item) => ({
        major: item.major,
        count: item._count.id,
      })),
    };
  }
}
